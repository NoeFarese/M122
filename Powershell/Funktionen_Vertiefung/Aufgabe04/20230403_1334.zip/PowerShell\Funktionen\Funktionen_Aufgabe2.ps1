﻿function message ($message)
{
    echo $message
}

message "message"