﻿<# Funktion welche "Message from function" ausgibt#>

function message ()
{
    echo "Message from function"
}

message